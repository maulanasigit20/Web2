-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 25, 2021 at 06:34 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bukutamu`
--

-- --------------------------------------------------------

--
-- Table structure for table `data_tamu`
--

CREATE TABLE `data_tamu` (
  `nama` varchar(30) NOT NULL,
  `nohp` text NOT NULL,
  `email` varchar(20) NOT NULL,
  `pesan` varchar(1000) NOT NULL,
  `tanggal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `data_tamu`
--

INSERT INTO `data_tamu` (`nama`, `nohp`, `email`, `pesan`, `tanggal`) VALUES
('Sigit Maulana', '087766554455', 'contoh1@mail.com', 'contoh pesan 1', '2021-03-25'),
('Maulana Sigit', '082255336655', 'contoh2@mail.com', 'contoh pesan 2', '2021-03-25'),
('Sella Cantika', '087766554433', 'contoh3@mail.com', 'contoh pesan 3', '2021-03-25'),
('Cantika Sella', '082244335566', 'contoh4@mail.com', 'contoh pesan 4', '2021-03-25'),
('Ariana Grande', '086655443355', 'contoh5@mail.com', 'contoh pesan 5', '2021-03-25');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
